// ObraMunicipio/list/list.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ObrasMunicipio } from 'src/app/models/obras-municipio.model';
import { ObrasMunicipioService } from 'src/app/services/obraMunicipio/obra-municipio.service';
import Swal from 'sweetalert2';
// import { Router } from '@angular/router'; // Import Router if you need navigation

@Component({
  selector: 'app-list-municipality-construction',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListObraMunicipioComponent implements OnInit {

  obramunicipios: ObrasMunicipio[] = []; // Array to store links
  // Inject the service and Router (if needed)
  constructor(private ObrasMunicipioService: ObrasMunicipioService , private router: Router) { }

  ngOnInit(): void {
    // Call the service to get the list
    this.ObrasMunicipioService.list().subscribe(data => {
      this.obramunicipios = data; // Assign data to the array property
    });
  }

  // Methods for edit and delete (adjust ID type based on your model)
  edit(id: number) {
    this.router.navigate(['obra-municipio/update', id])
    // Implement navigation
  }

  delete(id: number) {
  console.log("Delete seguro with id:", id);
        Swal.fire({
          title: 'Eliminar',
          text: "Está seguro que quiere eliminar el registro?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Si, eliminar',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.isConfirmed) {
            this.ObrasMunicipioService.delete(id).subscribe(data => {
              Swal.fire(
                'Eliminado!',
                'Registro eliminado correctamente.',
                'success'
              )
              this.ngOnInit();
            });
          }
        })
  }
}