import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MunicipioRoutingModule } from './municipio-routing.module';
import { ListComponent } from './list/list.component';
import { ManageComponent } from './manage/manage.component';


@NgModule({
  declarations: [
    ListComponent,
    ManageComponent
  ],
  imports: [
    CommonModule,
    MunicipioRoutingModule
  ]
})
export class MunicipioModule { }
