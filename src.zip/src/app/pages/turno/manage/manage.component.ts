import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Turno } from 'src/app/models/turno.model';
import { TurnoService } from 'src/app/services/turno/turno.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.scss']
})
export class ManageComponent implements OnInit {

  mode: number = 1; // 1: Ver, 2: Crear, 3: Editar

  turno: Turno = {
    id: 0,
    maquinaId: 0,
    operarioId: 0,
    estado: '',
    fechaInicio: new Date(),
    fechaFin: new Date(),
    novedadId: undefined
  };

  constructor(
    private activateRoute: ActivatedRoute,
    private turnoService: TurnoService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const currentUrl = this.activateRoute.snapshot.url.join('/');
    if (currentUrl.includes('view')) this.mode = 1;
    else if (currentUrl.includes('create')) this.mode = 2;
    else if (currentUrl.includes('update')) this.mode = 3;

    const id = Number(this.activateRoute.snapshot.params['id']);
    if (id && this.mode !== 2) {
      this.getTurno(id);
    }
  }

  getTurno(id: number): void {
    this.turnoService.view(id).subscribe({
      next: (turno) => {
        this.turno = turno;
        console.log('Turno cargado:', this.turno);
      },
      error: (error) => {
        console.error('Error al obtener turno:', error);
        Swal.fire('Error', 'No se pudo cargar el turno.', 'error');
      }
    });
  }

  create(): void {
    this.turnoService.create(this.turno).subscribe({
      next: () => {
        Swal.fire('Creado', 'Registro creado correctamente.', 'success')
          .then(() => this.router.navigate(['/turno/list']));
      },
      error: (error) => {
        console.error('Error al crear turno:', error);
        Swal.fire('Error', 'No se pudo crear el registro.', 'error');
      }
    });
  }

  update(): void {
    this.turnoService.update(this.turno).subscribe({
      next: () => {
        Swal.fire('Actualizado', 'Registro actualizado correctamente.', 'success')
          .then(() => this.router.navigate(['/turno/list']));
      },
      error: (error) => {
        console.error('Error al actualizar turno:', error);
        Swal.fire('Error', 'No se pudo actualizar el registro.', 'error');
      }
    });
  }

  delete(id: number): void {
    Swal.fire({
      title: 'Eliminar',
      text: '¿Está seguro que desea eliminar este turno?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33'
    }).then((result) => {
      if (result.isConfirmed) {
        this.turnoService.delete(id).subscribe({
          next: () => {
            Swal.fire('Eliminado', 'Registro eliminado correctamente.', 'success');
            this.router.navigate(['/turno/list']);
          },
          error: () => {
            Swal.fire('Error', 'No se pudo eliminar el turno.', 'error');
          }
        });
      }
    });
  }

  back(): void {
    this.router.navigate(['/turno/list']);
  }
}
