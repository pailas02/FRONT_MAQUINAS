import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Obra } from 'src/app/models/obra.model';
import { Combo } from 'src/app/models/combo.model';
import { Municipio } from 'src/app/models/municipio.model';
import { ObraService } from 'src/app/services/obra/obra.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.scss']
})
export class ManageComponent implements OnInit {

  mode: number = 1; // 1: Ver, 2: Crear, 3: Actualizar

  obra: Obra = {
    id: 0,
    nombre: '',
    descripcion: '',
    comboId: undefined,
    municipioId: 0
  };

  combos: Combo[] = [];
  municipios: Municipio[] = [];

  constructor(
    private activateRoute: ActivatedRoute,
    private obraService: ObraService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const currentUrl = this.activateRoute.snapshot.url.join('/');
    if (currentUrl.includes('view')) this.mode = 1;
    else if (currentUrl.includes('create')) this.mode = 2;
    else if (currentUrl.includes('update')) this.mode = 3;

    this.loadCombos();
    this.loadMunicipios();

    const idParam = this.activateRoute.snapshot.params['id'];
    const id = Number(idParam);
    if (id && this.mode !== 2) {
      this.getObra(id);
    }
  }

  getObra(id: number): void {
    this.obraService.view(id).subscribe({
      next: (obra) => {
        this.obra = obra;
        console.log('Obra cargada correctamente:', obra);
      },
      error: (error) => {
        console.error('Error al obtener la obra:', error);
        Swal.fire('Error', 'No se pudo obtener la obra.', 'error');
      }
    });
  }

  create(): void {
    this.obraService.create(this.obra).subscribe({
      next: () => {
        Swal.fire('Creado', 'Registro creado correctamente.', 'success')
          .then(() => this.router.navigate(['/obra/list']));
      },
      error: (error) => {
        console.error('Error al crear la obra:', error);
        Swal.fire('Error', 'No se pudo crear el registro.', 'error');
      }
    });
  }

  update(): void {
    this.obraService.update(this.obra).subscribe({
      next: () => {
        Swal.fire('Actualizado', 'Registro actualizado correctamente.', 'success')
          .then(() => this.router.navigate(['/obra/list']));
      },
      error: (error) => {
        console.error('Error al actualizar la obra:', error);
        Swal.fire('Error', 'No se pudo actualizar el registro.', 'error');
      }
    });
  }

  delete(id: number): void {
    Swal.fire({
      title: 'Eliminar',
      text: '¿Está seguro que desea eliminar esta obra?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33'
    }).then((result) => {
      if (result.isConfirmed) {
        this.obraService.delete(id).subscribe({
          next: () => {
            Swal.fire('Eliminado', 'Registro eliminado correctamente.', 'success');
            this.router.navigate(['/obra/list']);
          },
          error: (error) => {
            console.error('Error al eliminar la obra:', error);
            Swal.fire('Error', 'No se pudo eliminar el registro.', 'error');
          }
        });
      }
    });
  }

  back(): void {
    this.router.navigate(['/obra/list']);
  }

  loadCombos(): void {
    this.obraService.getCombos().subscribe({
      next: (data) => this.combos = data,
      error: () => Swal.fire('Error', 'No se pudieron cargar los combos', 'error')
    });
  }

  loadMunicipios(): void {
    this.obraService.getMunicipios().subscribe({
      next: (data) => this.municipios = data,
      error: () => Swal.fire('Error', 'No se pudieron cargar los municipios', 'error')
    });
  }
}
