import { Factura } from './factura.model';

describe('Factura', () => {
  it('should create an instance', () => {
    expect(new Factura()).toBeTruthy();
  });
});
