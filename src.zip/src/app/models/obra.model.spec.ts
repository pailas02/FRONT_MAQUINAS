import { Obra } from './obra.model';

describe('Obra', () => {
  it('should create an instance', () => {
    expect(new Obra()).toBeTruthy();
  });
});
