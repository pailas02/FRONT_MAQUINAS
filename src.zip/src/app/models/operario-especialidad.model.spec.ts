import { OperarioEspecialidad } from './operario-especialidad.model';

describe('OperarioEspecialidad', () => {
  it('should create an instance', () => {
    expect(new OperarioEspecialidad()).toBeTruthy();
  });
});
