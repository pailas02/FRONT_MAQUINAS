import { Maquina } from "./maquina.model";
import { Servicio } from "./servicio.model";

export class Combo {
  id?: number; // <- corregido
  descripcion?: string;
  maquinaId?: Maquina;
  servicioId?: Servicio;
}
