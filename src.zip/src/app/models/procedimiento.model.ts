import { Mantenimiento } from "./mantenimiento.model";

export class Procedimiento {
     id?: number;
    nombre?: string;
    descripcion?: string;
    mantenimientos?: Mantenimiento[];
}

