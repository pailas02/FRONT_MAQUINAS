import { Maquina } from "./maquina.model";

export class TipoServicio {
    id?: number;
    nombre?: string;
    maquinaId?: Maquina
}
