export class Theater {
    
    id?: number;
    location?: string;
    capacity?: number;
}
