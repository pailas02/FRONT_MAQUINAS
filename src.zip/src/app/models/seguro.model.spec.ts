import { Seguro } from './seguro.model';

describe('Seguro', () => {
  it('should create an instance', () => {
    expect(new Seguro()).toBeTruthy();
  });
});
