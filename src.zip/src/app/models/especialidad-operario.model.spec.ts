import { EspecialidadOperario } from './especialidad-operario.model';

describe('EspecialidadOperario', () => {
  it('should create an instance', () => {
    expect(new EspecialidadOperario()).toBeTruthy();
  });
});
