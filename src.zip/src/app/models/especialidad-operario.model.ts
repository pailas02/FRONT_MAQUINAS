import { Especialidad } from "./especialidad.model";
import { Operario } from "./operario.model";

export class EspecialidadOperario {
    id?: number;
    especialidadId?: Especialidad;
    operarioId?: Operario;
    
}
