import { Evidencia } from './evidencia.model';

describe('Evidencia', () => {
  it('should create an instance', () => {
    expect(new Evidencia()).toBeTruthy();
  });
});
