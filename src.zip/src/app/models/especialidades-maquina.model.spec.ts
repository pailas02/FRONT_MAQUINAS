import { EspecialidadesMaquina } from './especialidades-maquina.model';

describe('EspecialidadesMaquina', () => {
  it('should create an instance', () => {
    expect(new EspecialidadesMaquina()).toBeTruthy();
  });
});
