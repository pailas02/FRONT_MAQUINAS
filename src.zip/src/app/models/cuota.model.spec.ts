import { Cuota } from './cuota.model';

describe('Cuota', () => {
  it('should create an instance', () => {
    expect(new Cuota()).toBeTruthy();
  });
});
