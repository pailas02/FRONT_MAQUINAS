import { Combo } from "./combo.model";

export class Servicio {
    id?: number;
    costo?: number;
    prioridad?: number;
    tipoServicio?: string;
    fechaInicio?: Date;
    fechaFin?: Date;
    estado?: string;
    ubicacion?: string;
    historico?: string;
    comboId?: Combo;
    combos?: Combo[];
    
}

