import { Municipio } from "./municipio.model";
import { Obra } from "./obra.model";

export class ObrasMunicipio {
    id?: number;
    obra_id?: Obra;
    municipio_id?: Municipio
}
