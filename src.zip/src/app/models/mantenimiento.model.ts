export class Mantenimiento {
     id?: number;
    fecha?: Date;
    estado?: string;
    maquina_id?: number;
    responsable?: string;
}
