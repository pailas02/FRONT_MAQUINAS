import { MaquinaCombo } from './maquina-combo.model';

describe('MaquinaCombo', () => {
  it('should create an instance', () => {
    expect(new MaquinaCombo()).toBeTruthy();
  });
});
