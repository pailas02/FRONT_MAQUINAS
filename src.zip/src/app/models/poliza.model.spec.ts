import { Poliza } from './poliza.model';

describe('Poliza', () => {
  it('should create an instance', () => {
    expect(new Poliza()).toBeTruthy();
  });
});
