import { Departamento } from './departamento.model';

describe('Departamento', () => {
  it('should create an instance', () => {
    expect(new Departamento()).toBeTruthy();
  });
});
