import { Municipio } from "./municipio.model";

export class Departamento {
    id?: number;
    nombre?: string;
    municipioId?: number;
    municipio?: Municipio;
    municipios?: Municipio[];
}
