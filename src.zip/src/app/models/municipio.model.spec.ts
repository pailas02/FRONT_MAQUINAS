import { Municipio } from './municipio.model';

describe('Municipio', () => {
  it('should create an instance', () => {
    expect(new Municipio()).toBeTruthy();
  });
});
