export class Operario {
    id?: number;
    nombre?: string;
    apellido?: string;
    email?: string;
    userId?: string;
    experiencia?: string;
    especialdidad?: string;
}
