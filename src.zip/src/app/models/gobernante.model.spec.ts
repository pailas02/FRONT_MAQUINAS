import { Gobernante } from './gobernante.model';

describe('Gobernante', () => {
  it('should create an instance', () => {
    expect(new Gobernante()).toBeTruthy();
  });
});
