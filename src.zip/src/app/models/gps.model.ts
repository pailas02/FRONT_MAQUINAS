import { Maquina } from "./maquina.model";

export class Gps {
    id?: number;
    latitud?: string;
    longitud?: string;
    maquinaId?: Maquina;
}
