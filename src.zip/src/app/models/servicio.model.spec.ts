import { Servicio } from './servicio.model';

describe('Servicio', () => {
  it('should create an instance', () => {
    expect(new Servicio()).toBeTruthy();
  });
});
