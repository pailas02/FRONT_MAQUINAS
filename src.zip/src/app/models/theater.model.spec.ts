import { Theater } from './theater.model';

describe('Theater', () => {
  it('should create an instance', () => {
    expect(new Theater()).toBeTruthy();
  });
});
