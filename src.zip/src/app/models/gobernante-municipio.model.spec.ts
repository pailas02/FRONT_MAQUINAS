import { GobernanteMunicipio } from './gobernante-municipio.model';

describe('GobernanteMunicipio', () => {
  it('should create an instance', () => {
    expect(new GobernanteMunicipio()).toBeTruthy();
  });
});
