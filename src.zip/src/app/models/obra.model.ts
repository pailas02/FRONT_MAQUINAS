import { Combo } from "./combo.model";

export class Obra {
    id?: number;
    nombre?: string;
    descripcion?: string;
    comboId?: Combo;
    combos?: Combo[];
    municipioId?: number;
    municipios?: number[];
}