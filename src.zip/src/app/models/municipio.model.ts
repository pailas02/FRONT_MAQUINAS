import { Departamento } from "./departamento.model";

export class Municipio {
     id?: number;
    nombre?: string;
    departamentoId?: number;
    departamento?: Departamento
}
