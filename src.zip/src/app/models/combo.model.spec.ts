import { Combo } from './combo.model';

describe('Combo', () => {
  it('should create an instance', () => {
    expect(new Combo()).toBeTruthy();
  });
});
