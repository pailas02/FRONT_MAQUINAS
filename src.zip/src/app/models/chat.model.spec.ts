import { Chat } from './chat.model';

describe('Chat', () => {
  it('should create an instance', () => {
    expect(new Chat()).toBeTruthy();
  });
});
