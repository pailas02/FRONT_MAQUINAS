import { Operario } from './operario.model';

describe('Operario', () => {
  it('should create an instance', () => {
    expect(new Operario()).toBeTruthy();
  });
});
