import { Maquina } from './maquina.model';

describe('Maquina', () => {
  it('should create an instance', () => {
    expect(new Maquina()).toBeTruthy();
  });
});
