import { Combo } from "./combo.model";
import { Gps } from "./gps.model";
import { Mantenimiento } from "./mantenimiento.model";
import { Operario } from "./operario.model";
import { Seguro } from "./seguro.model";
import { TipoServicio } from "./tipo-servicio.model";

export class Maquina {
    id?: number;
    marca?: string;
    modelo?: string;
    estado?: string;
    gps?: Gps;
    combo?:Combo;
    operarioid?:Operario;
    seguroid?: Seguro;
    mantenumiento?: Mantenimiento;
    tipoServicio?: TipoServicio;
    combos?: Combo[];
    mantenimientos?: Mantenimiento[];
    seguros?: Seguro[];
    operarios?: Operario[];
}
