import { Gps } from './gps.model';

describe('Gps', () => {
  it('should create an instance', () => {
    expect(new Gps()).toBeTruthy();
  });
});
