import { Procedimiento } from './procedimiento.model';

describe('Procedimiento', () => {
  it('should create an instance', () => {
    expect(new Procedimiento()).toBeTruthy();
  });
});
