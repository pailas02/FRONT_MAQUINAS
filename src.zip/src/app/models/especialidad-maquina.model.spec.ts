import { EspecialidadMaquina } from './especialidad-maquina.model';

describe('EspecialidadMaquina', () => {
  it('should create an instance', () => {
    expect(new EspecialidadMaquina()).toBeTruthy();
  });
});
