import { TipoServicio } from './tipo-servicio.model';

describe('TipoServicio', () => {
  it('should create an instance', () => {
    expect(new TipoServicio()).toBeTruthy();
  });
});
