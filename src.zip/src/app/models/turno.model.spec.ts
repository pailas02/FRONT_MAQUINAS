import { Turno } from './turno.model';

describe('Turno', () => {
  it('should create an instance', () => {
    expect(new Turno()).toBeTruthy();
  });
});
