import { Especialidad } from './especialidad.model';

describe('Especialidad', () => {
  it('should create an instance', () => {
    expect(new Especialidad()).toBeTruthy();
  });
});
