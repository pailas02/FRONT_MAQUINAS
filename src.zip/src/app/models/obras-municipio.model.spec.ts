import { ObrasMunicipio } from './obras-municipio.model';

describe('ObrasMunicipio', () => {
  it('should create an instance', () => {
    expect(new ObrasMunicipio()).toBeTruthy();
  });
});
