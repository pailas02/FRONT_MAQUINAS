import { Novedad } from './novedad.model';

describe('Novedad', () => {
  it('should create an instance', () => {
    expect(new Novedad()).toBeTruthy();
  });
});
