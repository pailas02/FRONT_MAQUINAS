import { Mensaje } from './mensaje.model';

describe('Mensaje', () => {
  it('should create an instance', () => {
    expect(new Mensaje()).toBeTruthy();
  });
});
