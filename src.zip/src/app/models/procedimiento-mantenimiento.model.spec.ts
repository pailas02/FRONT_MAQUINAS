import { ProcedimientoMantenimiento } from './procedimiento-mantenimiento.model';

describe('ProcedimientoMantenimiento', () => {
  it('should create an instance', () => {
    expect(new ProcedimientoMantenimiento()).toBeTruthy();
  });
});
