import { GobernanteDepartamento } from './gobernante-departamento.model';

describe('GobernanteDepartamento', () => {
  it('should create an instance', () => {
    expect(new GobernanteDepartamento()).toBeTruthy();
  });
});
