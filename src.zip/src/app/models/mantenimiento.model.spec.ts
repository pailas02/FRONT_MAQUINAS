import { Mantenimiento } from './mantenimiento.model';

describe('Mantenimiento', () => {
  it('should create an instance', () => {
    expect(new Mantenimiento()).toBeTruthy();
  });
});
