export class MaquinaCombo {
      id?: number;
    maquina_id?: number;
    combo_id?: number;
    fecha_inicio?: Date;
    fecha_fin?: Date;
}
