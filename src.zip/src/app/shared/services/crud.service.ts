import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CrudService<T> {
  constructor(private http: HttpClient) {}

  list(endpoint: string): Observable<T[]> {
    return this.http.get<T[]>(endpoint);
  }

  getById(endpoint: string, id: string): Observable<T> {
    return this.http.get<T>(`${endpoint}/${id}`);
  }

  create(endpoint: string, data: T): Observable<T> {
    return this.http.post<T>(endpoint, data);
  }

  update(endpoint: string, id: string, data: T): Observable<T> {
    return this.http.put<T>(`${endpoint}/${id}`, data);
  }

  delete(endpoint: string, id: string): Observable<void> {
    return this.http.delete<void>(`${endpoint}/${id}`);
  }
}

